<?php

//Conexão com o banco

class Conexao{

 private $mysqli;
 
 
 function conectar(){
    $mysqli = new mysqli("localhost","u253536359_nuwe", "james56118992", "u253536359_nuwe") or die ("deu erro"); 
    
    return $mysqli;
 }
 
 
  
  
  
  
}


?>