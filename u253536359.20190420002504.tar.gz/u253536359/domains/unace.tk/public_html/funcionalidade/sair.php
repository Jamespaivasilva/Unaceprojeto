<?php

// matar a sessão

session_start();
session_destroy();

header('Location: ../interface/inicio.php');
























?>