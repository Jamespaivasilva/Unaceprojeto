<!DOCTYPE html>
<head>
   <link rel="stylesheet" href="../css/rodape.css"/>
</head>
<body>
   <div class="container-fluid corpo">
      <br/>  
      <div class="row">
         <div class="col-md-4">
            <img src="http://d9hhrg4mnvzow.cloudfront.net/unace.acejundiai.com.br/6168f273-logo2-ace-jundiai_03g01f03g01e000000.png" class="img-fluid" /> 
         </div>
      </div>
      <div class="row">
         <div class="col-md-4">
         </div>
         <div class="col-md-2">
            <img src="http://d9hhrg4mnvzow.cloudfront.net/unace.acejundiai.com.br/56f48231-005-phone-receiver1_00o00o00o00o000000.png" class="img-fluid" /> 11 3308.4301
         </div>
         <div class="col-md-2">
            <img src="http://d9hhrg4mnvzow.cloudfront.net/unace.acejundiai.com.br/acbbad61-close-envelope_00o00o00o00o000000.png"class="img-fluid" /> unace@acejundiai.com.br
         </div>
      </div>
      <br/>
      <div class="row">
         <div class="col-md-4">
         </div>
         <div class="col-md-6">
            <img src="http://d9hhrg4mnvzow.cloudfront.net/unace.acejundiai.com.br/66622a67-004-placeholder-tool2_00o00o00o00o000000.png"/>R. Rangel Pestana, 533 - Edifício Palácio do Comércio - Centro - Jundiaí/SP
         </div>
      </div>
      <br/><br/>
      <div class="row">
         <div class="col-md-4"></div>
         <div class="col-md-6">
            ACE Jundiaí © Copyright 2018. Todos os Direitos Reservados.
         </div>
      </div>
   </div>
   </div>
</body>